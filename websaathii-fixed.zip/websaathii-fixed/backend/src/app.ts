import express, { type Express } from "express";
import cors from "cors";
import generateRouter from "./routes/generate.js";
import healthRouter from "./routes/health.js";

const app: Express = express();

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", healthRouter);
app.use("/api", generateRouter);

export default app;
