import { Router } from "express";
import OpenAI from "openai";

const router = Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ─── Fallback HTML (used when AI fails or key is missing) ──────────────────
function buildFallbackHtml(
  businessName: string,
  businessType: string,
  location: string,
  services: string[],
  language: string
): string {
  const isHindi = language === "Hindi";
  const isTelugu = language === "Telugu";

  const heroTitle = isHindi
    ? `${businessName} में आपका स्वागत है`
    : isTelugu
    ? `${businessName}కు స్వాగతం`
    : `Welcome to ${businessName}`;

  const aboutTitle = isHindi ? "हमारे बारे में" : isTelugu ? "మా గురించి" : "About Us";
  const servicesLabel = isHindi ? "हमारी सेवाएं" : isTelugu ? "మా సేవలు" : "Our Services";
  const contactLabel = isHindi ? "हमसे संपर्क करें" : isTelugu ? "మమ్మల్ని సంప్రదించండి" : "Contact Us";
  const locationLabel = isHindi ? "पता" : isTelugu ? "చిరునామా" : "Address";

  const aboutText = isHindi
    ? `${businessName} ${location} में एक विश्वसनीय ${businessType} है। हम उच्च गुणवत्ता सेवाएं प्रदान करते हैं।`
    : isTelugu
    ? `${businessName} ${location}లో ఒక నమ్మకమైన ${businessType}. మేము అత్యుత్తమ సేవలు అందిస్తాము.`
    : `${businessName} is a trusted ${businessType} in ${location}. We are committed to providing the best quality services to our customers.`;

  const serviceCards = services
    .map(
      (s) => `
    <div style="background:#fff;border-radius:16px;padding:28px 24px;box-shadow:0 2px 12px rgba(37,99,235,0.08);text-align:center;border:1px solid #e0e7ff;transition:transform 0.2s;">
      <div style="font-size:36px;margin-bottom:14px;">✅</div>
      <h3 style="margin:0;color:#1e293b;font-size:15px;font-weight:700;">${s}</h3>
    </div>`
    )
    .join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${businessName}</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Segoe UI',Arial,sans-serif;color:#334155;background:#f8fafc}
    a{color:inherit;text-decoration:none}
    header{background:linear-gradient(135deg,#2563eb 0%,#16a34a 100%);color:#fff;padding:100px 24px 80px;text-align:center}
    header h1{font-size:clamp(30px,6vw,56px);font-weight:900;margin-bottom:16px;line-height:1.1}
    header p{font-size:18px;opacity:.85;margin-bottom:32px}
    .cta{display:inline-block;background:#fff;color:#2563eb;font-weight:800;font-size:16px;padding:14px 36px;border-radius:50px;box-shadow:0 4px 20px rgba(0,0,0,.15);transition:.2s}
    .cta:hover{transform:translateY(-2px);box-shadow:0 8px 30px rgba(0,0,0,.2)}
    section{max-width:1000px;margin:0 auto;padding:72px 24px}
    h2{font-size:30px;font-weight:800;color:#1e293b;margin-bottom:12px;text-align:center}
    .section-sub{text-align:center;color:#64748b;margin-bottom:44px;font-size:16px}
    .about-box{background:#fff;border-radius:20px;padding:44px;box-shadow:0 4px 20px rgba(37,99,235,.07);border:1px solid #e0e7ff;font-size:17px;line-height:1.8;color:#475569;text-align:center;max-width:700px;margin:0 auto}
    .services-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:20px}
    .contact-section{background:linear-gradient(135deg,#eff6ff,#f0fdf4);border-radius:24px;padding:60px 24px;margin:0 24px 60px;text-align:center}
    .contact-card{background:#fff;border-radius:16px;padding:36px 40px;max-width:440px;margin:0 auto;box-shadow:0 4px 16px rgba(37,99,235,.08);border:1px solid #e0e7ff}
    .contact-card p{margin-bottom:12px;font-size:16px;display:flex;align-items:center;gap:10px}
    .contact-card strong{color:#1e293b}
    footer{background:#1e293b;color:#94a3b8;text-align:center;padding:28px;font-size:14px}
    @media(max-width:600px){.services-grid{grid-template-columns:1fr 1fr}}
  </style>
</head>
<body>
  <header>
    <h1>${heroTitle}</h1>
    <p>${businessType} &mdash; ${location}</p>
    <a href="#contact" class="cta">${isHindi ? "संपर्क करें" : isTelugu ? "సంప్రదించండి" : "Get In Touch"}</a>
  </header>

  <section>
    <h2>${aboutTitle}</h2>
    <p class="section-sub">${isHindi ? "हमारी कहानी" : isTelugu ? "మా కథ" : "Our story"}</p>
    <div class="about-box">${aboutText}</div>
  </section>

  <section style="background:#fff;border-radius:0;padding:72px 24px;">
    <h2>${servicesLabel}</h2>
    <p class="section-sub">${isHindi ? "जो हम प्रदान करते हैं" : isTelugu ? "మేము అందించేది" : "What we offer"}</p>
    <div class="services-grid">${serviceCards}</div>
  </section>

  <div id="contact" class="contact-section">
    <h2>${contactLabel}</h2>
    <p class="section-sub" style="margin-bottom:32px">${isHindi ? "हम यहाँ हैं" : isTelugu ? "మేము ఇక్కడ ఉన్నాము" : "We're here for you"}</p>
    <div class="contact-card">
      <p>📍 <strong>${locationLabel}:</strong> ${location}</p>
      <p>🏢 <strong>${isHindi ? "व्यवसाय" : isTelugu ? "వ్యాపారం" : "Business"}:</strong> ${businessName}</p>
      <p>⭐ <strong>${isHindi ? "प्रकार" : isTelugu ? "రకం" : "Type"}:</strong> ${businessType}</p>
    </div>
  </div>

  <footer>
    <p>&copy; ${new Date().getFullYear()} ${businessName}. ${isHindi ? "सर्वाधिकार सुरक्षित" : isTelugu ? "అన్ని హక్కులు రిజర్వ్ చేయబడ్డాయి" : "All rights reserved"}.</p>
  </footer>
</body>
</html>`;
}

// ─── POST /api/generate ────────────────────────────────────────────────────
router.post("/generate", async (req, res) => {
  const { businessName, businessType, location, selectedItems, language } = req.body as {
    businessName?: string;
    businessType?: string;
    location?: string;
    selectedItems?: string[];
    language?: string;
  };

  // Validation
  if (!businessName || !businessType || !location || !selectedItems || !language) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }
  if (!Array.isArray(selectedItems) || selectedItems.length === 0) {
    res.status(400).json({ error: "selectedItems must be a non-empty array" });
    return;
  }

  const validLanguages = ["English", "Hindi", "Telugu"];
  const resolvedLanguage = validLanguages.includes(language) ? language : "English";

  // SSE headers to keep connection alive and avoid proxy timeouts
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  // If no API key is set, return fallback immediately
  if (!process.env.OPENAI_API_KEY) {
    console.warn("[generate] OPENAI_API_KEY not set — serving fallback HTML");
    const fallback = buildFallbackHtml(businessName, businessType, location, selectedItems, resolvedLanguage);
    res.write(`data: ${JSON.stringify({ html: fallback, usedFallback: true })}\n\n`);
    res.end();
    return;
  }

  const prompt = `You are a professional web designer. Create a complete, beautiful, modern single-page website for a local Indian business.

Business Name: ${businessName}
Business Type: ${businessType}
Location: ${location}
Services/Products: ${selectedItems.join(", ")}
Language: Write ALL visible text content in ${resolvedLanguage}. This is critical — every heading, paragraph, button, label must be in ${resolvedLanguage}.

Requirements:
1. Hero section with a bold headline and call-to-action button
2. About section with 2-3 sentences about the business
3. Services section showing each of: ${selectedItems.join(", ")} as a card with icon
4. Contact section with address (${location})
5. Footer with copyright

Design:
- Use a modern blue (#2563eb) and green (#16a34a) color scheme
- Clean, modern inline CSS only (no external stylesheets, no CDN links, no JS frameworks)
- Fully responsive — works on mobile and desktop
- Rounded corners, subtle shadows, professional typography

CRITICAL: Return ONLY raw HTML. No markdown, no code fences, no preamble. Start with <!DOCTYPE html> and end with </html>.`;

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 8192,
      stream: true,
    });

    let fullHtml = "";
    for await (const chunk of stream) {
      fullHtml += chunk.choices[0]?.delta?.content ?? "";
    }

    // Strip markdown fences if model wrapped anyway
    const cleanHtml = fullHtml
      .replace(/^```html\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();

    const finalHtml = cleanHtml.startsWith("<!") || cleanHtml.startsWith("<html")
      ? cleanHtml
      : buildFallbackHtml(businessName, businessType, location, selectedItems, resolvedLanguage);

    res.write(`data: ${JSON.stringify({ html: finalHtml })}\n\n`);
    res.end();
  } catch (err) {
    const error = err as { message?: string };
    console.error("[generate] OpenAI error:", error.message);

    // Always serve fallback — never leave the user with nothing
    const fallback = buildFallbackHtml(businessName, businessType, location, selectedItems, resolvedLanguage);
    res.write(`data: ${JSON.stringify({ html: fallback, usedFallback: true })}\n\n`);
    res.end();
  }
});

export default router;
