import { build } from "esbuild";
import { rm } from "fs/promises";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

await rm(resolve(__dirname, "dist"), { recursive: true, force: true });

await build({
  entryPoints: [resolve(__dirname, "src/index.ts")],
  platform: "node",
  bundle: true,
  format: "esm",
  outdir: resolve(__dirname, "dist"),
  outExtension: { ".js": ".mjs" },
  external: ["*.node"],
  sourcemap: "linked",
  banner: {
    js: `
import { createRequire as __crReq } from 'node:module';
import { fileURLToPath as __fup } from 'node:url';
import { dirname as __dn } from 'node:path';
globalThis.require = __crReq(import.meta.url);
globalThis.__filename = __fup(import.meta.url);
globalThis.__dirname = __dn(globalThis.__filename);
`.trim(),
  },
});

console.log("Build complete → dist/index.mjs");
