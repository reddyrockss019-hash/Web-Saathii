import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Download,
  Edit3,
  RotateCcw,
  ArrowLeft,
  Monitor,
  Smartphone,
  RefreshCw,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { useGenerateWebsite } from "@/hooks/use-generate";
import { cn } from "@/lib/utils";

export default function Preview() {
  const [, setLocation] = useLocation();
  const [htmlContent, setHtmlContent] = useState("");
  const [editValue, setEditValue] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [viewMode, setViewMode] = useState<"desktop" | "mobile">("desktop");
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const builderData = (() => {
    try {
      return JSON.parse(localStorage.getItem("builderData") || "null");
    } catch {
      return null;
    }
  })();

  const { mutate: regenerate, isPending: isRegenerating } = useGenerateWebsite();

  useEffect(() => {
    const stored = localStorage.getItem("generatedHtml");
    if (stored) {
      setHtmlContent(stored);
      setEditValue(stored);
    } else {
      setLocation("/builder");
    }
  }, [setLocation]);

  const handleDownload = () => {
    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "websaathii-site.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleSaveEdit = () => {
    setHtmlContent(editValue);
    localStorage.setItem("generatedHtml", editValue);
    setIsEditing(false);
  };

  const handleRegenerate = () => {
    if (!builderData) { setLocation("/builder"); return; }
    regenerate(builderData, {
      onSuccess: (data) => {
        setHtmlContent(data.html);
        setEditValue(data.html);
        localStorage.setItem("generatedHtml", data.html);
      },
    });
  };

  if (isRegenerating) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center shadow-xl animate-pulse">
            <RefreshCw className="w-8 h-8 text-white animate-spin" />
          </div>
          <div>
            <h2 className="text-2xl font-bold mb-2 text-slate-900">Regenerating...</h2>
            <p className="text-slate-500 text-sm">This takes about 15–20 seconds</p>
          </div>
        </div>
      </div>
    );
  }

  if (!htmlContent) return null;

  return (
    <div className="h-screen flex overflow-hidden bg-slate-100">
      {/* Sidebar */}
      <div className="w-72 shrink-0 bg-white border-r border-slate-200 flex flex-col shadow-xl shadow-black/5 z-10">
        {/* Header */}
        <div className="px-4 py-3.5 border-b border-slate-100 flex items-center gap-2.5 bg-slate-50/80">
          <button
            onClick={() => setLocation("/")}
            className="p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-500" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="font-bold text-sm">
              Web<span className="text-green-500">Saathii</span>
            </span>
          </div>
        </div>

        {/* Status */}
        <div className="px-5 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2 text-green-600 mb-1">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-semibold">Website is ready!</span>
          </div>
          <p className="text-xs text-slate-400">Review, edit, or download below.</p>
        </div>

        {/* Actions */}
        <div className="flex-1 p-4 flex flex-col gap-2.5 overflow-y-auto">
          <button
            onClick={handleRegenerate}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700 transition-all text-left"
          >
            <RefreshCw className="w-4 h-4 text-blue-500 shrink-0" />
            Regenerate Website
          </button>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className={cn(
              "flex items-center gap-3 w-full px-4 py-3 rounded-xl border text-sm font-medium transition-all text-left",
              isEditing
                ? "border-orange-300 bg-orange-50 text-orange-700"
                : "border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700"
            )}
          >
            <Edit3 className="w-4 h-4 shrink-0" />
            {isEditing ? "Cancel Editing" : "Edit HTML"}
          </button>

          {isEditing && (
            <button
              onClick={handleSaveEdit}
              className="flex items-center gap-3 w-full px-4 py-3 rounded-xl bg-green-500 text-white text-sm font-semibold transition-all hover:bg-green-600 text-left"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              Save Changes
            </button>
          )}

          <button
            onClick={handleDownload}
            className={cn(
              "flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-semibold transition-all text-left shadow-sm",
              downloadSuccess
                ? "bg-green-500 text-white"
                : "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20"
            )}
          >
            {downloadSuccess ? (
              <><CheckCircle2 className="w-4 h-4 shrink-0" /> Downloaded!</>
            ) : (
              <><Download className="w-4 h-4 shrink-0" /> Download HTML</>
            )}
          </button>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100">
          <button
            onClick={() => setLocation("/builder")}
            className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-500 hover:bg-slate-50 transition-all"
          >
            <RotateCcw className="w-4 h-4" /> Start Over
          </button>
        </div>
      </div>

      {/* Preview area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* View toggle */}
        <div className="h-12 bg-white border-b border-slate-200 flex items-center justify-center gap-1.5 px-4 shadow-sm">
          {(["desktop", "mobile"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setViewMode(m)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                viewMode === m
                  ? "bg-blue-100 text-blue-700"
                  : "text-slate-400 hover:bg-slate-100"
              )}
            >
              {m === "desktop" ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
              {m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden flex items-center justify-center p-6">
          {isEditing ? (
            <div className="w-full h-full bg-white rounded-2xl shadow-lg border border-slate-200 flex flex-col overflow-hidden">
              <div className="bg-slate-900 px-4 py-2.5 flex justify-between items-center">
                <span className="text-sm font-mono text-slate-400">index.html</span>
                <button
                  onClick={handleSaveEdit}
                  className="px-3 py-1 text-xs font-semibold bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
                >
                  Save Changes
                </button>
              </div>
              <textarea
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="flex-1 w-full p-4 font-mono text-xs bg-slate-950 text-green-400 focus:outline-none resize-none"
                spellCheck={false}
              />
            </div>
          ) : (
            <div
              className={cn(
                "transition-all duration-300 ease-in-out overflow-hidden",
                viewMode === "mobile"
                  ? "w-[390px] h-[844px] rounded-[3rem] border-[10px] border-slate-800 shadow-2xl"
                  : "w-full h-full rounded-2xl border border-slate-200 shadow-lg bg-white"
              )}
            >
              <iframe
                title="Preview"
                srcDoc={htmlContent}
                className="w-full h-full border-none bg-white"
                sandbox="allow-scripts"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
