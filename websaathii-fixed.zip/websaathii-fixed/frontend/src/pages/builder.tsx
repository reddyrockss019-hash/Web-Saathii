import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Sparkles,
  Building2,
  Store,
  MapPin,
  Globe,
} from "lucide-react";
import { useGenerateWebsite, type GenerateWebsiteRequest } from "@/hooks/use-generate";
import { cn } from "@/lib/utils";

const BUSINESS_TYPES = [
  "Bakery", "Restaurant", "Salon", "Gym", "Retail Shop",
  "Clinic", "School", "Photography", "Catering", "Other",
];

const SUGGESTED_SERVICES: Record<string, string[]> = {
  Bakery: ["Cakes", "Pastries", "Cookies", "Bread", "Custom Orders", "Cake Decoration"],
  Restaurant: ["Dine-In", "Takeaway", "Home Delivery", "Catering", "Special Events", "Party Bookings"],
  Salon: ["Haircut", "Hair Color", "Facial", "Manicure", "Pedicure", "Bridal Makeup"],
  Gym: ["Personal Training", "Group Classes", "Yoga", "Zumba", "Strength Training", "Cardio"],
  "Retail Shop": ["Home Delivery", "In-Store Shopping", "Online Ordering", "Gift Wrapping", "Exchange Policy"],
  Clinic: ["Consultation", "Lab Tests", "Pharmacy", "Home Visits", "Emergency Care", "Specialist Referral"],
  School: ["Primary Education", "Secondary Education", "After-School Programs", "Online Classes", "Counseling"],
  Photography: ["Wedding Photography", "Portrait Sessions", "Event Coverage", "Product Photography", "Photo Editing"],
  Catering: ["Wedding Catering", "Corporate Events", "Birthday Parties", "Home Delivery", "Veg/Non-Veg Options"],
  Other: ["Our Services", "About Us", "Contact Us", "Portfolio", "Testimonials", "Special Offers"],
};

const LANGUAGES = ["English", "Hindi", "Telugu"] as const;

const STEP_LABELS = ["Business", "Services", "Language", "Review"];

export default function Builder() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<GenerateWebsiteRequest>>({
    businessName: "",
    businessType: "Other",
    location: "",
    selectedItems: [],
    language: "English",
  });

  const { mutate: generateWebsite, isPending, error } = useGenerateWebsite();

  const updateForm = (updates: Partial<GenerateWebsiteRequest>) =>
    setFormData((prev) => ({ ...prev, ...updates }));

  const isStep1Valid = !!(formData.businessName && formData.businessType && formData.location);
  const isStep2Valid = !!(formData.selectedItems && formData.selectedItems.length > 0);
  const isStep3Valid = !!formData.language;

  const handleGenerate = () => {
    if (!formData.businessName || !formData.businessType || !formData.location ||
        !formData.selectedItems?.length || !formData.language) return;

    const request = formData as GenerateWebsiteRequest;
    localStorage.setItem("builderData", JSON.stringify(request));

    generateWebsite(request, {
      onSuccess: (data) => {
        localStorage.setItem("generatedHtml", data.html);
        setLocation("/preview");
      },
    });
  };

  if (isPending) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/30 flex items-center justify-center p-6">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="flex flex-col items-center text-center gap-8 max-w-sm w-full"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center shadow-2xl shadow-blue-500/30 animate-pulse">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold tracking-tight mb-2 text-slate-900">
              Building your website...
            </h2>
            <p className="text-slate-500">
              Writing content in <strong className="text-slate-700">{formData.language}</strong> for{" "}
              <strong className="text-slate-700">{formData.businessName}</strong>
            </p>
          </div>
          <div className="w-full space-y-2">
            <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-600 to-green-500 rounded-full"
                initial={{ width: "0%" }}
                animate={{ width: "92%" }}
                transition={{ duration: 18, ease: "easeOut" }}
              />
            </div>
            <p className="text-xs text-slate-400 text-right">~15–20 seconds</p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center gap-3">
        <button
          onClick={() => setLocation("/")}
          className="p-2 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-slate-500" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-bold text-lg">
            Web<span className="text-green-500">Saathii</span>
          </span>
        </div>
      </div>

      <main className="flex-1 w-full max-w-3xl mx-auto p-6 flex flex-col gap-6">
        {/* Progress */}
        <div className="flex items-center gap-2 relative mt-2">
          {STEP_LABELS.map((label, i) => {
            const s = i + 1;
            return (
              <div key={s} className="flex items-center flex-1 last:flex-none">
                <div className="flex flex-col items-center gap-1">
                  <div
                    className={cn(
                      "w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300",
                      step === s
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-110"
                        : step > s
                        ? "bg-green-100 text-green-600"
                        : "bg-slate-100 text-slate-400"
                    )}
                  >
                    {step > s ? <Check className="w-4 h-4" /> : s}
                  </div>
                  <span className="text-xs font-medium text-slate-400 hidden sm:block">
                    {label}
                  </span>
                </div>
                {i < STEP_LABELS.length - 1 && (
                  <div className="flex-1 mx-2 h-0.5 rounded-full bg-slate-200 -mt-5 overflow-hidden">
                    <div
                      className="h-full bg-blue-400 transition-all duration-500"
                      style={{ width: step > s ? "100%" : "0%" }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 p-6 sm:p-8">
            <AnimatePresence mode="wait">
              {/* STEP 1 */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  className="space-y-7"
                >
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-1">
                      Tell us about your business
                    </h2>
                    <p className="text-slate-500 text-sm">
                      Fill in the details below to get started.
                    </p>
                  </div>
                  <div className="space-y-5 max-w-md">
                    <div className="space-y-1.5">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-blue-500" /> Business Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Royal Bakes"
                        value={formData.businessName}
                        onChange={(e) => updateForm({ businessName: e.target.value })}
                        className="w-full h-12 px-4 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Store className="w-4 h-4 text-blue-500" /> Business Type
                      </label>
                      <select
                        value={formData.businessType}
                        onChange={(e) =>
                          updateForm({ businessType: e.target.value, selectedItems: [] })
                        }
                        className="w-full h-12 px-4 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all appearance-none"
                      >
                        {BUSINESS_TYPES.map((t) => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-blue-500" /> Location
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Mumbai, India"
                        value={formData.location}
                        onChange={(e) => updateForm({ location: e.target.value })}
                        className="w-full h-12 px-4 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {/* STEP 2 */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  className="space-y-7"
                >
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-1">
                      What services do you offer?
                    </h2>
                    <p className="text-slate-500 text-sm">
                      Select all that apply — we'll feature these on your site.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {SUGGESTED_SERVICES[formData.businessType || "Other"].map((service) => {
                      const selected = formData.selectedItems?.includes(service);
                      return (
                        <button
                          key={service}
                          type="button"
                          onClick={() => {
                            const curr = formData.selectedItems || [];
                            updateForm({
                              selectedItems: selected
                                ? curr.filter((i) => i !== service)
                                : [...curr, service],
                            });
                          }}
                          className={cn(
                            "p-3.5 rounded-xl border-2 text-sm font-medium text-left flex items-center justify-between transition-all duration-150",
                            selected
                              ? "border-blue-500 bg-blue-50 text-blue-700 shadow-sm"
                              : "border-slate-200 bg-white text-slate-700 hover:border-blue-300 hover:bg-slate-50"
                          )}
                        >
                          {service}
                          {selected && <Check className="w-4 h-4 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* STEP 3 */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  className="space-y-7"
                >
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-1">
                      Choose your website language
                    </h2>
                    <p className="text-slate-500 text-sm">
                      All content will be written natively in the selected language.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {LANGUAGES.map((lang) => {
                      const selected = formData.language === lang;
                      const emoji = lang === "English" ? "🇬🇧" : lang === "Hindi" ? "🇮🇳" : "🌺";
                      return (
                        <button
                          key={lang}
                          type="button"
                          onClick={() => updateForm({ language: lang })}
                          className={cn(
                            "p-6 rounded-2xl border-2 flex flex-col items-center gap-3 h-36 transition-all duration-150",
                            selected
                              ? "border-blue-500 bg-blue-50 shadow-md scale-105"
                              : "border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50"
                          )}
                        >
                          <span className="text-3xl">{emoji}</span>
                          <Globe
                            className={cn(
                              "w-6 h-6",
                              selected ? "text-blue-600" : "text-slate-400"
                            )}
                          />
                          <span
                            className={cn(
                              "text-base font-bold",
                              selected ? "text-blue-700" : "text-slate-700"
                            )}
                          >
                            {lang}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* STEP 4 */}
              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  className="space-y-7"
                >
                  <div className="text-center max-w-xl mx-auto">
                    <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-5">
                      <Sparkles className="w-8 h-8 text-blue-600" />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 mb-3">Ready to generate!</h2>
                    <p className="text-slate-500">
                      We have everything needed to build a stunning website for{" "}
                      <strong className="text-slate-800">{formData.businessName}</strong>.
                    </p>
                  </div>

                  <div className="bg-slate-50 rounded-2xl border border-slate-200 p-5 max-w-lg mx-auto space-y-3">
                    {[
                      ["Business", formData.businessType],
                      ["Location", formData.location],
                      ["Services", formData.selectedItems?.join(", ")],
                      ["Language", formData.language],
                    ].map(([label, value]) => (
                      <div key={label} className="flex justify-between items-start py-2 border-b border-slate-200 last:border-0">
                        <span className="text-sm text-slate-500">{label}</span>
                        <span className="text-sm font-semibold text-slate-800 text-right max-w-[55%]">
                          {value}
                        </span>
                      </div>
                    ))}
                  </div>

                  {error && (
                    <div className="p-4 bg-red-50 text-red-600 rounded-xl border border-red-200 text-sm text-center max-w-lg mx-auto">
                      {error.message || "Generation failed. Please try again."}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer nav */}
          <div className="px-6 sm:px-8 py-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
            <button
              onClick={() => setStep((s) => Math.max(1, s - 1))}
              disabled={step === 1}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-600 hover:border-slate-300 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>

            {step < 4 ? (
              <button
                onClick={() => setStep((s) => Math.min(4, s + 1))}
                disabled={
                  (step === 1 && !isStep1Valid) ||
                  (step === 2 && !isStep2Valid) ||
                  (step === 3 && !isStep3Valid)
                }
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
              >
                Next <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleGenerate}
                className="flex items-center gap-2 px-7 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 text-white text-sm font-bold hover:from-blue-700 hover:to-blue-600 transition-all shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50"
              >
                <Sparkles className="w-4 h-4" /> Generate My Website
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
