import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Sparkles, Globe, Zap, Download } from "lucide-react";

const features = [
  "No coding or design skills needed",
  "AI-powered content in your language",
  "English, Hindi & Telugu supported",
  "Download your complete website instantly",
];

const steps = [
  {
    icon: <Sparkles className="w-5 h-5" />,
    title: "Tell us about your business",
    desc: "Name, type, location — takes 30 seconds",
  },
  {
    icon: <Globe className="w-5 h-5" />,
    title: "Pick your language",
    desc: "We write all content natively in your language",
  },
  {
    icon: <Zap className="w-5 h-5" />,
    title: "AI builds your website",
    desc: "Full hero, services, contact section — done in 20s",
  },
  {
    icon: <Download className="w-5 h-5" />,
    title: "Download & go live",
    desc: "One HTML file, ready to host anywhere",
  },
];

export default function Landing() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/40 overflow-hidden">
      {/* Ambient blobs */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute -left-[20%] -top-[10%] h-[60%] w-[55%] rounded-full bg-blue-500/6 blur-[160px]" />
        <div className="absolute -right-[15%] top-[40%] h-[50%] w-[45%] rounded-full bg-green-400/6 blur-[160px]" />
      </div>

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-6xl mx-auto">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-green-500 flex items-center justify-center shadow-md">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight">
            Web<span className="text-green-500">Saathii</span>
          </span>
        </div>
        <button
          onClick={() => setLocation("/builder")}
          className="text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors"
        >
          Start building →
        </button>
      </nav>

      {/* Hero */}
      <main className="relative z-10 max-w-6xl mx-auto px-6 py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="inline-flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-full px-4 py-1.5 mb-6"
            >
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-sm font-medium text-blue-700">
                AI-powered · Free to use · No signup needed
              </span>
            </motion.div>

            <h1 className="text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.08] mb-6">
              Build your
              <br />
              website in{" "}
              <span className="bg-gradient-to-r from-blue-600 to-green-500 bg-clip-text text-transparent">
                minutes
              </span>
              .
            </h1>

            <p className="text-lg text-slate-500 mb-8 max-w-md leading-relaxed">
              Tell us about your business, choose your language, and our AI
              generates a complete, beautiful website — no tech skills needed.
            </p>

            <ul className="space-y-3 mb-10">
              {features.map((f, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + i * 0.07 }}
                  className="flex items-center gap-3 text-sm font-medium text-slate-700"
                >
                  <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                  {f}
                </motion.li>
              ))}
            </ul>

            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              onClick={() => setLocation("/builder")}
              className="group flex items-center gap-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-base px-8 py-4 rounded-2xl shadow-xl shadow-blue-500/25 transition-all duration-200 hover:shadow-blue-500/40 hover:scale-105 active:scale-100"
            >
              <Sparkles className="w-5 h-5" />
              Build My Website — Free
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </motion.button>

            <p className="mt-4 text-xs text-slate-400">
              No account required · Works in English, Hindi & Telugu
            </p>
          </motion.div>

          {/* Right — how it works */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
            className="hidden lg:block"
          >
            <div className="bg-white rounded-3xl border border-slate-200/80 shadow-2xl shadow-slate-200/60 p-8">
              <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">
                How it works
              </p>
              <div className="space-y-6">
                {steps.map((step, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + i * 0.1 }}
                    className="flex items-start gap-4"
                  >
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-50 to-green-50 border border-slate-200 flex items-center justify-center text-blue-600 shrink-0">
                      {step.icon}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-0.5">
                        {step.title}
                      </p>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {step.desc}
                      </p>
                    </div>
                    {i < steps.length - 1 && (
                      <div className="absolute left-[52px] mt-10 w-0.5 h-6 bg-slate-100 -translate-x-1/2" />
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Example preview */}
              <div className="mt-8 rounded-2xl border border-slate-100 bg-gradient-to-br from-blue-600 to-green-500 p-5 text-white">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-white/40" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/40" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/40" />
                  <div className="flex-1 bg-white/20 rounded-full h-5 ml-2 flex items-center px-3">
                    <span className="text-xs text-white/70">royalbakes.com</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="h-3 bg-white/30 rounded-full w-3/4" />
                  <div className="h-3 bg-white/20 rounded-full w-1/2" />
                  <div className="h-3 bg-white/20 rounded-full w-2/3" />
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4">
                  {["Cakes", "Pastries", "Custom"].map((s) => (
                    <div
                      key={s}
                      className="bg-white/20 rounded-xl p-2 text-center text-xs font-medium"
                    >
                      {s}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
